/* --- Generated the 19/11/2023 at 19:25 --- */
/* --- heptagon compiler, version 1.05.00 (compiled fri. sep. 15 15:42:3 CET 2023) --- */
/* --- Command line: /home/hightechnology/.opam/4.08.0/bin/heptc -target c main.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "main_types.h"

