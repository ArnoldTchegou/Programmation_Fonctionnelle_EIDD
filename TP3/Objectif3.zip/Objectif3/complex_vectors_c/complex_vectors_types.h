/* --- Generated the 6/10/2023 at 4:46 --- */
/* --- heptagon compiler, version 1.05.00 (compiled fri. sep. 15 15:42:3 CET 2023) --- */
/* --- Command line: /home/hightechnology/.opam/4.08.0/bin/heptc -target c complex_vectors.ept --- */

#ifndef COMPLEX_VECTORS_TYPES_H
#define COMPLEX_VECTORS_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
#include "complex_add_types.h"
#include "complex_vec_types.h"
#include "complex_vec_io_types.h"
typedef Complex_add__complex Complex_vectors__monvecteur[3];
  
#endif // COMPLEX_VECTORS_TYPES_H
