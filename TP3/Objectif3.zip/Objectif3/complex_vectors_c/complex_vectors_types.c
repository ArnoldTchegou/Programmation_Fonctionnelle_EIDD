/* --- Generated the 6/10/2023 at 4:46 --- */
/* --- heptagon compiler, version 1.05.00 (compiled fri. sep. 15 15:42:3 CET 2023) --- */
/* --- Command line: /home/hightechnology/.opam/4.08.0/bin/heptc -target c complex_vectors.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "complex_vectors_types.h"

