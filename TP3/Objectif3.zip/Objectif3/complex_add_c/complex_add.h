/* --- Generated the 6/10/2023 at 4:44 --- */
/* --- heptagon compiler, version 1.05.00 (compiled fri. sep. 15 15:42:3 CET 2023) --- */
/* --- Command line: /home/hightechnology/.opam/4.08.0/bin/heptc -target c complex_add.ept --- */

#ifndef COMPLEX_ADD_H
#define COMPLEX_ADD_H

#include "complex_add_types.h"
typedef struct Complex_add__complex_add_out {
  Complex_add__complex o;
} Complex_add__complex_add_out;

void Complex_add__complex_add_step(Complex_add__complex i1,
                                   Complex_add__complex i2,
                                   Complex_add__complex_add_out* _out);

#endif // COMPLEX_ADD_H
