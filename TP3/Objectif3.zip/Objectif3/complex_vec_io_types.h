#ifndef COMPLEX_H
#define COMPLEX_H
#include "complex_vectors_types.h"
typedef struct Complex_vec_io__print_complex_out{

}Complex_vec_io__print_complex_out;

typedef struct Complex_vec_io__print_complex_vector_out{

}Complex_vec_io__print_complex_vector_out;

typedef struct Complex_vec_io__read_complex_vector_out{
	Complex_add__complex o[3];
}Complex_vec_io__read_complex_vector_out;


#endif // COMPLEX_H

